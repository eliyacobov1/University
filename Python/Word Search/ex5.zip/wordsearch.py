import sys
import os.path

number_of_aguments=4
error_arguments="number of arguments no applicable,\nenter word_file,matrix_file,output_file,directions"
error_wordlist="Error:word file was not found"
error_directions="Error:invalid directions"
error_matrix="Error:matrix file was not found"
word_list_txt=1
mat_txt=2
output_txt=3
directions_string=4

def check_input_args(args):
    # we check the argument list and return an error if needed,if everything is in order,we return None
    if len(args)!= number_of_aguments+1:
        return error_arguments

    if not os.path.isfile(args[word_list_txt]):
        return error_wordlist

    if not os.path.isfile(args[mat_txt]):
        return error_matrix

    for n in range(len(args[directions_string])):
        d=args[directions_string][n]
        if d!='u' and d!='d' and d!='l' and d!='r' and d!='w' and d!='x' and d!='y' and d!='z':
            return error_directions
    return None


def read_wordlist_file(filename):
    with open(filename,'r') as f:
        wordlist=[]
        for line in f:
            wordlist.append(line[:-1])
        return wordlist


def read_matrix_file(filename):
    with open(filename) as f:
        matrix = []
        line_counter=0
        for line in f:
            matrix.append([])
            for n in range(len(line)):
                # add only the letters to the matrix (no comas or /n)
                if(line[n].isalpha()==True):
                    matrix[line_counter].append(line[n])
            line_counter += 1
        return matrix

def u_search(word_list,matrix):
    return_list=[]
    for n in range (len(word_list)):
        # set a pre condition to check if the word can fit vertically in the matrix
        if len(word_list[n])<=len(matrix):
            # because the search direction is up,we start from the end of the matrix up to point where
            # the number of lines equals the length of the word
            for m in range(len(matrix)-1, len(word_list[n])-2 ,- 1):
                # number of columns
                for l in range((len(matrix[m]))):
                    if(matrix[m][l] == (word_list[n])[0]):
                        # variable that counts letters in the word
                        letter_counter=1
                        # variable that progresses a row up each time we advance
                        m_1 = m-1
                        # variable that checks if letters in the matrix match letters in the word
                        letter_are_correct=True
                        while(letter_counter<len(word_list[n])):
                            if (matrix[m_1][l] == word_list[n][letter_counter]):
                                letter_counter+=1
                                m_1-=1
                            else:
                                letter_are_correct=False
                                break
                        ##at this point,we check if all the letters in the word were found in the matrix segment
                        ##which we were checking
                        if(letter_are_correct==True):
                            ##variable that checks if word is already in the least,so we can determine if
                            ##to create a new tuple for this word
                            word_not_in_list=True
                            for t in range (len(return_list)):
                                if return_list[t][0]==word_list[n]:
                                    ##if it is in the list,we add 1 to the number of times that it was
                                    ##found
                                    lst=list(return_list[t])
                                    lst[1]+=1
                                    return_list[t]=tuple(lst)
                                    word_not_in_list=False
                                    break
                            ##if not,we create a new tuple with the word and the number 1
                            if word_not_in_list==True:
                                return_list.append((word_list[n],1))
    return_list =dict(return_list)
    return return_list

def d_search(word_list,matrix):
    return_list = []
    for n in range(len(word_list)):
        # set a pre condition to check if the word can fit vertically in the matrix
        if len(word_list[n]) <= len(matrix):
            # because the search direction is down,we look up until the row
            # which equals the subtraction of the length of word from the total rows
            for m in range(len(matrix)-len(word_list[n])+1):
                #number of columns
                for l in range((len(matrix[m]))):
                    if (matrix[m][l] == (word_list[n])[0]):
                        # variable that counts letters in the word
                        letter_counter = 1
                        # variable that progresses a row down each time we advance
                        m_1 = m + 1
                        # variable that checks if letters in the matrix match letters in the word
                        letter_are_correct = True
                        while (letter_counter < len(word_list[n])):
                            if (matrix[m_1][l] == word_list[n][letter_counter]):
                                letter_counter += 1
                                m_1 += 1
                            else:
                                letter_are_correct = False
                                break
                        ##at this point,we check if all the letters in the word were found in the matrix segmant
                        ##which we were checking
                        if (letter_are_correct == True):
                            ##variable that checks if word is already in the least,so we can determine if
                            ##to create a new tuple for this word
                            word_not_in_list = True
                            for t in range(len(return_list)):
                                if return_list[t][0] == word_list[n]:
                                    ##if it is in the list,we add 1 to the number of times that it was
                                    ##found
                                    lst = list(return_list[t])
                                    lst[1] += 1
                                    return_list[t] = tuple(lst)
                                    word_not_in_list = False
                                    break
                            ##if not,we create a new tuple with the word and the number 1
                            if word_not_in_list == True:
                                return_list.append((word_list[n], 1))
    return_list =dict(return_list)
    return return_list

def l_search(word_list,matrix):
    return_list = []
    for n in range(len(word_list)):
        # set a pre condition to check if the word can fit horizontally in the matrix
        if len(word_list[n]) <= len(matrix[0]):
            # because the search direction is left,we start from the rightmost column and
            # advance up until the subtraction of the length of the word from the length of each row
            for m in range(len(matrix)):
                for l in range((len(matrix[0]))-1,len(word_list[n])-2,-1):
                    if (matrix[m][l] == (word_list[n])[0]):
                        # variable that counts letters in the word
                        letter_counter = 1
                        # variable that progresses a column left each time we advance
                        l_1 = l - 1
                        # variable that checks if letters in the matrix match letters in the word
                        letter_are_correct = True
                        while (letter_counter < len(word_list[n])):
                            if (matrix[m][l_1] == word_list[n][letter_counter]):
                                letter_counter += 1
                                l_1 -= 1
                            else:
                                letter_are_correct = False
                                break
                        ##at this point,we check if all the letters in the word were found in the matrix segmant
                        ##which we were checking
                        if (letter_are_correct == True):
                            ##variable that checks if word is already in the least,so we can determine if
                            ##to create a new tuple for this word
                            word_not_in_list = True
                            for t in range(len(return_list)):
                                if return_list[t][0] == word_list[n]:
                                    ##if it is in the list,we add 1 to the number of times that it was
                                    ##found
                                    lst = list(return_list[t])
                                    lst[1] += 1
                                    return_list[t] = tuple(lst)
                                    word_not_in_list = False
                                    break
                            ##if not,we create a new tuple with the word and the number 1
                            if word_not_in_list == True:
                                return_list.append((word_list[n], 1))
    return_list =dict(return_list)
    return return_list

def r_search(word_list,matrix):
    return_list = []
    for n in range(len(word_list)):
        # set a pre condition to check if the word can fit horizontally in the matrix
        if len(word_list[n]) <= len(matrix[0]):
            # because the search direction is right,we look up left until
            #  the subtraction of the length of the word from the length of each row
            for m in range(len(matrix)):
                for l in range(len(matrix[0])-len(word_list[n])+1):
                    if (matrix[m][l] == (word_list[n])[0]):
                        # variable that counts letters in the word
                        letter_counter = 1
                        # variable that progresses a column right each time we advance
                        l_1 = l + 1
                        # variable that checks if letters in the matrix match letters in the word
                        letter_are_correct = True
                        while (letter_counter < len(word_list[n])):
                            if (matrix[m][l_1] == word_list[n][letter_counter]):
                                letter_counter += 1
                                l_1 += 1
                            else:
                                letter_are_correct = False
                                break
                        ##at this point,we check if all the letters in the word were found in the matrix segmant
                        ##which we were checking
                        if (letter_are_correct == True):
                            ##variable that checks if word is already in the least,so we can determine if
                            ##to create a new tuple for this word
                            word_not_in_list = True
                            for t in range(len(return_list)):
                                if return_list[t][0] == word_list[n]:
                                    ##if it is in the list,we add 1 to the number of times that it was
                                    ##found
                                    lst = list(return_list[t])
                                    lst[1] += 1
                                    return_list[t] = tuple(lst)
                                    word_not_in_list = False
                                    break
                            ##if not,we create a new tuple with the word and the number 1
                            if word_not_in_list == True:
                                return_list.append((word_list[n], 1))
    return_list =dict(return_list)
    return return_list

def w_search(word_list,matrix):
    return_list = []
    for n in range(len(word_list)):
        # set a pre condition to check if the word can fit horizontally and vertically in the matrix
        if len(word_list[n]) <= len(matrix[0]) and len(word_list[n]) <= len(matrix):
            # same condition as in u_search for rows
            for m in range(len(matrix)-1, len(word_list[n])-2 ,- 1):
                #same condition as in r_search for columns
                for l in range(len(matrix[0])-len(word_list[n])+1):
                    if (matrix[m][l] == (word_list[n])[0]):
                        # variable that counts letters in the word
                        letter_counter = 1
                        # variable that progresses a column right each time we advance
                        l_1 = l + 1
                        # # variable that progresses a row up each time we advance
                        m_1 = m-1
                        # variable that checks if letters in the matrix match letters in the word
                        letter_are_correct = True
                        while (letter_counter < len(word_list[n])):
                            if (matrix[m_1][l_1] == word_list[n][letter_counter]):
                                letter_counter += 1
                                l_1 += 1
                                m_1 -=1
                            else:
                                letter_are_correct = False
                                break
                        ##at this point,we check if all the letters in the word were found in the matrix segmant
                        ##which we were checking
                        if (letter_are_correct == True):
                            ##variable that checks if word is already in the least,so we can determine if
                            ##to create a new tuple for this word
                            word_not_in_list = True
                            for t in range(len(return_list)):
                                if return_list[t][0] == word_list[n]:
                                    ##if it is in the list,we add 1 to the number of times that it was
                                    ##found
                                    lst = list(return_list[t])
                                    lst[1] += 1
                                    return_list[t] = tuple(lst)
                                    word_not_in_list = False
                                    break
                            ##if not,we create a new tuple with the word and the number 1
                            if word_not_in_list == True:
                                return_list.append((word_list[n], 1))
    return_list =dict(return_list)
    return return_list

def x_search(word_list,matrix):
    return_list = []
    for n in range(len(word_list)):
        # set a pre condition to check if the word can fit horizontally and vertically in the matrix
        if len(word_list[n]) <= len(matrix[0]) and len(word_list[n]) <= len(matrix):
            # same condition as in u_search for rows
            for m in range(len(matrix) - 1, len(word_list[n]) - 2, - 1):
                # same condition as in l_search for columns
                for l in range((len(matrix[0]))-1,len(word_list[n])-2,-1):
                    if (matrix[m][l] == (word_list[n])[0]):
                        # variable that counts letters in the word
                        letter_counter = 1
                        # variable that progresses a column left each time we advance
                        l_1 = l - 1
                        # # variable that progresses a row up each time we advance
                        m_1 = m - 1
                        # variable that checks if letters in the matrix match letters in the word
                        letter_are_correct = True
                        while (letter_counter < len(word_list[n])):
                            if (matrix[m_1][l_1] == word_list[n][letter_counter]):
                                letter_counter += 1
                                l_1 -= 1
                                m_1 -= 1
                            else:
                                letter_are_correct = False
                                break
                        ##at this point,we check if all the letters in the word were found in the matrix segmant
                        ##which we were checking
                        if (letter_are_correct == True):
                            ##variable that checks if word is already in the least,so we can determine if
                            ##to create a new tuple for this word
                            word_not_in_list = True
                            for t in range(len(return_list)):
                                if return_list[t][0] == word_list[n]:
                                    ##if it is in the list,we add 1 to the number of times that it was
                                    ##found
                                    lst = list(return_list[t])
                                    lst[1] += 1
                                    return_list[t] = tuple(lst)
                                    word_not_in_list = False
                                    break
                            ##if not,we create a new tuple with the word and the number 1
                            if word_not_in_list == True:
                                return_list.append((word_list[n], 1))
    return_list =dict(return_list)
    return return_list

def y_search(word_list,matrix):
    return_list = []
    for n in range(len(word_list)):
        # set a pre condition to check if the word can fit horizontally and vertically in the matrix
        if len(word_list[n]) <= len(matrix[0]) and len(word_list[n]) <= len(matrix):
            # same condition as in d_search for rows
            for m in range(len(matrix)-len(word_list[n])+1):
                # same condition as in r_search for columns
                for l in range(len(matrix[0]) - len(word_list[n]) + 1):
                    if (matrix[m][l] == (word_list[n])[0]):
                        # variable that counts letters in the word
                        letter_counter = 1
                        # variable that progresses a column right each time we advance
                        l_1 = l + 1
                        # # variable that progresses a row down each time we advance
                        m_1 = m + 1
                        # variable that checks if letters in the matrix match letters in the word
                        letter_are_correct = True
                        while (letter_counter < len(word_list[n])):
                            if (matrix[m_1][l_1] == word_list[n][letter_counter]):
                                letter_counter += 1
                                l_1 += 1
                                m_1 += 1
                            else:
                                letter_are_correct = False
                                break
                        ##at this point,we check if all the letters in the word were found in the matrix segmant
                        ##which we were checking
                        if (letter_are_correct == True):
                            ##variable that checks if word is already in the least,so we can determine if
                            ##to create a new tuple for this word
                            word_not_in_list = True
                            for t in range(len(return_list)):
                                if return_list[t][0] == word_list[n]:
                                    ##if it is in the list,we add 1 to the number of times that it was
                                    ##found
                                    lst = list(return_list[t])
                                    lst[1] += 1
                                    return_list[t] = tuple(lst)
                                    word_not_in_list = False
                                    break
                            ##if not,we create a new tuple with the word and the number 1
                            if word_not_in_list == True:
                                return_list.append((word_list[n], 1))
    return_list =dict(return_list)
    return return_list

def z_search(word_list,matrix):
    return_list = []
    for n in range(len(word_list)):
        # set a pre condition to check if the word can fit horizontally and vertically in the matrix
        if len(word_list[n]) <= len(matrix[0]) and len(word_list[n]) <= len(matrix):
            # same condition as in d_search for rows
            for m in range(len(matrix) - len(word_list[n]) + 1):
                # same condition as in l_search for columns
                for l in range((len(matrix[0])) - 1, len(word_list[n]) - 2, -1):
                    if (matrix[m][l] == (word_list[n])[0]):
                        # variable that counts letters in the word
                        letter_counter = 1
                        # variable that progresses a column right each time we advance
                        l_1 = l - 1
                        # # variable that progresses a row down each time we advance
                        m_1 = m + 1
                        # variable that checks if letters in the matrix match letters in the word
                        letter_are_correct = True
                        while (letter_counter < len(word_list[n])):
                            if (matrix[m_1][l_1] == word_list[n][letter_counter]):
                                letter_counter += 1
                                l_1 -= 1
                                m_1 += 1
                            else:
                                letter_are_correct = False
                                break
                        ##at this point,we check if all the letters in the word were found in the matrix segmant
                        ##which we were checking
                        if (letter_are_correct == True):
                            ##variable that checks if word is already in the least,so we can determine if
                            ##to create a new tuple for this word
                            word_not_in_list = True
                            for t in range(len(return_list)):
                                if return_list[t][0] == word_list[n]:
                                    ##if it is in the list,we add 1 to the number of times that it was
                                    ##found
                                    lst = list(return_list[t])
                                    lst[1] += 1
                                    return_list[t] = tuple(lst)
                                    word_not_in_list = False
                                    break
                            ##if not,we create a new tuple with the word and the number 1
                            if word_not_in_list == True:
                                return_list.append((word_list[n], 1))
    return_list=dict(return_list)
    return return_list

def find_words_in_matrix(word_list, matrix, directions):
    # a dictionary in which we put words from all directions
    final_list={}
    # a dictionary that helps us determine if a direction in the string appears more than once
    check_if_twice={}
    # a new string that will include 1 of each direction that was entered (if needed)
    direction=""
    for n in range (len(directions)):
        if directions[n] in check_if_twice:
            pass
        else:
            direction += (directions[n])
            check_if_twice.update({directions[n]:1})
    directions=direction
    # we created sub-functions that will be each searching a word in a certain direction
    # and for each direction which the user entered we run its intended function
    # we go through the list we get from each direction and check if the key was already added to the
    # final_list dictionary.if so,we add 1 appearance to the value,if not,we create a new key for the word

    for n in range(len(directions)):
        if(directions[n]=='u'):
            dict=u_search(word_list,matrix)
            for key,value in dict.items():
                if key in final_list:
                    final_list[key] += 1
                else:
                    final_list.update({key: value})

        if (directions[n] == 'd'):
            dict = d_search(word_list, matrix)
            for key,value in dict.items():
                if key in final_list:
                    final_list[key] += 1
                else:
                    final_list.update({key: value})

        if (directions[n] == 'l'):
            dict = l_search(word_list, matrix)
            for key,value in dict.items():
                if key in final_list:
                    final_list[key] += 1
                else:
                    final_list.update({key: value})

        if (directions[n] == 'r'):
            dict = r_search(word_list, matrix)
            for key,value in dict.items():
                if key in final_list:
                    final_list[key] += 1
                else:
                    final_list.update({key: value})

        if (directions[n] == 'w'):
            dict = w_search(word_list, matrix)
            for key,value in dict.items():
                if key in final_list:
                    final_list[key] += 1
                else:
                    final_list.update({key: value})

        if (directions[n] == 'x'):
            dict = x_search(word_list, matrix)
            for key,value in dict.items():
                if key in final_list:
                    final_list[key] += 1
                else:
                    final_list.update({key: value})

        if (directions[n] == 'y'):
            dict = y_search(word_list, matrix)
            for key,value in dict.items():
                if key in final_list.items():
                    final_list[key] += 1
                else:
                    final_list.update({key: value})

        if (directions[n] == 'z'):
            dict = z_search(word_list, matrix)
            for key,value in dict.items():
                if key in final_list:
                    final_list[key] += 1
                else:
                    final_list.update({key: value})

    # the list to which we convert all the values from the dictionary
    results = []
    for key,value in final_list.items():
        results.append((key,value))

    return results

def write_output_file(results, output_filename):
    f=open(output_filename,'w')
    for tuple in results:
        f.write(tuple[0]+", " +str(tuple[1])+'\n')

def run_matrix():
    # we run all the function with the parameters that we receive from the user in cmd
    check_args(sys.argv)
    if check_args(sys.argv)==None:
        words_list = read_wordlist_file(sys.argv[word_list_txt])
        matrix = read_matrix_file(sys.argv[mat_txt])
        directions = sys.argv[directions_string]
        if len(matrix) != 0 and len(words_list) != 0:
            final_list = find_words_in_matrix(words_list, matrix, directions)
            write_output_file(final_list,sys.argv[output_txt])
        else:
            final_list = []
            write_output_file(final_list,sys.argv[output_txt] )
    else:
        print(check_args(sys.argv))

if __name__ == '__main__':
    run_matrix()
