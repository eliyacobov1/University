import wordsearch

# i chose the function u_search that finds words from words_list
#  in the direction up that are in the matrix

def check_u_search():
    a=True
    b=True
    matrix_identical_letter=[]
    for n in range (5):
        matrix_identical_letter.append([])
        for m in range (5):
            matrix_identical_letter[n].append("A")
    lst_B=list(['A','A','A'])
    if wordsearch.u_search==['A','A','A',15]:
        a= True
    else:
        a= False

    empty_matrix = []
    lst_B = list(['B', 'B', 'B'])
    if wordsearch.u_search(lst_B,empty_matrix) == []:
        b= True
    else:
        b= False

    if a==True and b==True:
        return True
    else:
        return False

if __name__ == '__main__':
    check_u_search()






if __name__ == '__main__':



