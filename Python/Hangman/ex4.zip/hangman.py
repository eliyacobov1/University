import hangman_helper

def update_word_pattern(word,pattern,letter):
    l=list(pattern)
    for n in range (len(word)):
        if word[n]==letter:
            l[n]=letter
    return "".join(l)

def run_single_game(words_list):
    word = hangman_helper.get_random_word(words_list)
    pattern = ("_"*len(word))
    msg = hangman_helper.DEFAULT_MSG
    error_count = 0
    wrong_guess_lst = []
    # program starts a new,until the point when user reaches max errors or when he figures out the word
    while(error_count < hangman_helper.MAX_ERRORS and pattern != word):
        hangman_helper.display_state(pattern, error_count, wrong_guess_lst,msg, ask_play=False)
        input=hangman_helper.get_input()
        if(input[0]==hangman_helper.LETTER):
            if(input[1].islower() == False or len(input[1])>1):
                msg = hangman_helper.NON_VALID_MSG
                continue
        # checking if the letter was already chosen
        # (if it is in the wrong list or was already reveald in the word itself
            for n in range(len(wrong_guess_lst)):
                if input[1] == wrong_guess_lst[n]:
                    msg = hangman_helper.ALREADY_CHOSEN_MSG + input[1]
                    break
            if(msg == hangman_helper.ALREADY_CHOSEN_MSG + input[1]):
                 continue
            for n in range (len(pattern)):
                if pattern[n]==input[1]:
                    msg = hangman_helper.ALREADY_CHOSEN_MSG + input[1]
                    break
            if (msg == hangman_helper.ALREADY_CHOSEN_MSG + input[1]):
                continue
            ##check if letter is in the word and if so,use update word function on the letter
            for n in range(len(word)):
                if word[n] == input[1]:
                    pattern=update_word_pattern(word,pattern,input[1])
                    msg=hangman_helper.DEFAULT_MSG
                    break
            ##else add word to wrong list and start again
            else:
                wrong_guess_lst.append(input[1])
                error_count+=1
                msg=hangman_helper.DEFAULT_MSG
        else:
            if (input[0] == hangman_helper.HINT):
                msg=hangman_helper.HINT_MSG+choose_letter(filter_words_list(words_list,pattern,wrong_guess_lst),pattern)
    ##end of game,user gets massge with win or loss depends on how he fared
    if word == pattern:
        msg=hangman_helper.WIN_MSG
        hangman_helper.display_state(pattern, error_count, wrong_guess_lst,msg, ask_play=True)
    else:
        msg=hangman_helper.LOSS_MSG + word
        hangman_helper.display_state(pattern, error_count, wrong_guess_lst,msg, ask_play=True)

def main():
    words_list=hangman_helper.load_words(file='words.txt')
    run_single_game(words_list)
    input=hangman_helper.get_input()
    if input[1]==True:
        while input[1]==True:
            run_single_game(words_list)
            input = hangman_helper.get_input()

def filter_words_list(words,pattern,wrong_guess_lst):
    final_list=[]
    ##starts a concactanated loop,for each word in list it check the letters in the pattern
    ## and if a letter in in the wrong list
    for n in range (len(words)):
        ##filters words that are not on the same length as the pattern
        if len(words[n])==len(pattern):
            ##create a variable that will turn false if there is a mismatch with a certain letter
            ##between the word and the pattern
            check_if_not_matching_letter = True
            for m in range (len(pattern)):
                if(pattern[m].islower==True):
                    if pattern[m]==(words[n])[m]:
                        continue
                    else:
                        check_if_not_matching_letter=False
            ##if variable is true than we go on to next check to see if word is in wrong list
            if check_if_not_matching_letter==True:
                ##like before,we create a variable that will change to false if the word is in the list
                check_if_in_wrong_lst=True
                for p in range(len(wrong_guess_lst)):
                    for l in range (len(words[n])):
                        if (words[n])[l]==wrong_guess_lst[p]:
                            check_if_in_wrong_lst=False
                            break
                    if check_if_in_wrong_lst == False:
                        break
                #if the word got this far and passed all tests,it is eligible to enter the final list
                if check_if_in_wrong_lst==True:
                    final_list.append(words[n])
    return final_list

def choose_letter(words,pattern):
    abc_list=[]
    ##create abc list,the index number will represent each letter in the abc
    for n in range(26):
        abc_list.append(0)
    ##create a concactanated loop to go count each letter in each word in the list
    for n in range (len(words)):
        for m in range (len(words[n])):
            ##i didnt manage to define letter to index function,so instead,ord-97 dives the same result
            abc_list[ord((words[n])[m])-97]+=1
    ##a variable to check which letter was most frequent,and another to set the letter that will be returnd
    max_letter=0
    returned_letter=str
    for n in range (26):
        if abc_list[n]>max_letter:
            ##create new variable to check if letter is in pattern
            letter_not_in_pattern=True
            for m in range (len(pattern)):
                if chr(n+97)==pattern[m]:
                    letter_not_in_pattern=False
                    break
            ##if letter is not in pattern,sets its number of times as max letter and sets it as the letter that
            ##we return to the user
            if letter_not_in_pattern==True:
                max_letter=abc_list[n]
                returned_letter=chr(n+97)
    return returned_letter

if __name__ == '__main__':
    hangman_helper.start_gui_and_call_main(main)
    hangman_helper.close_gui()





